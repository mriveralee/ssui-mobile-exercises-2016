package com.mikeriv.ssui_2016.parcelableactivitystate;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by mlrivera on 10/15/16.
 */

// TODO implement the parcelable interface
public class PersonModel {

    private static final String DEFAULT_PERSON_NAME = "";
    private static final String DEFAULT_PERSON_FAVORITE_FOOD = "";
    private static final int DEFAULT_PERSON_AGE = 18;

    private String mName;
    private int mAge;
    private String mFavoriteFood;

    // TODO implement the parcelable interface's methods

    public PersonModel() {
        setName(DEFAULT_PERSON_NAME);
        setAge(DEFAULT_PERSON_AGE);
        setFavoriteFood(DEFAULT_PERSON_FAVORITE_FOOD);
    }

    public PersonModel(String name, int age, String favoriteFood) {
        setName(name);
        setAge(age);
        setFavoriteFood(favoriteFood);
    }

    public int getAge() {
        return mAge;
    }

    public String getName() {
        return mName;
    }

    public String getFavoriteFood() {
        return mFavoriteFood;
    }

    public void setName(String name) {
        if (name == null) {
            name = DEFAULT_PERSON_NAME;
        }
        mName = name;
    }

    public void setAge(int age) {
        if (age <= 0) {
            age = 1;
        }
        mAge = age;
    }

    public void setFavoriteFood(String favoriteFood) {
        if (favoriteFood == null) {
            favoriteFood = DEFAULT_PERSON_FAVORITE_FOOD;
        }
        mFavoriteFood = favoriteFood;
    }
}
